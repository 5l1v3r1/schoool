<?php 

include '../../../links/db.php';

echo "<hr><div class='text-center'>";
echo "<table class='table table-bordered table-striped table-responsive'>";
echo "<th class='text-center'>class</th>";
echo "<th class='text-center'>options</th>";
echo "<tr>";
echo "<td><form method='get' action=''><select name='stclass' class='form-control'>
<option >-------------------- class --------------------</option>
                <option>NURSERY 1</option>
                <option>NURSERY 2</option>
                <option>NURSERY 3</option>
                <option>PRIMARY 1</option>
                <option>PRIMARY 2</option>
                <option>PRIMARY 3</option>
                <option>PRIMARY 4</option>
                <option>PRIMARY 5</option>
                <option>PRIMARY 6</option>
                <option>JSS 1</option>
                <option>JSS 2</option>
                <option>JSS 3</option>
                <option>SSS 1</option>
                <option>SSS 2</option>
                <option>SSS 3</option>
</select></td>";
echo "<td><input name='subclass' type='submit' class='btn btn-success' value='view class'></form></td>";
echo "</tr>";
echo "</table>";
echo "</div>";

if(isset($_GET['subclass'])){
  if(!empty($_GET['stclass'])){
    $stclass=mysqli_real_escape_string($con, $_GET['stclass']);

    switch($stclass){

      case "NURSERY 1":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>REG NO</th>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $id=mysqli_real_escape_string($con, $row['id']);
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$id."</td>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "<td><a href='edit.index.php?reg_no=$id&s=$s&m=$m&f=$f&sex=$g&c=$stclass' data-toggle='modal'>edit</a></td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "NURSERY 2":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "NURSERY 3":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "PRIMARY 1":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "PRIMARY 2":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "PRIMARY 3":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "PRIMARY 4":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "PRIMARY 5":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "PRIMARY 6":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "JSS 1":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "JSS 2":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "JSS 3":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "SSS 1":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "SSS 2":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
     if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;

      case "SSS 3":
      $sql="SELECT * FROM profiles WHERE class='$stclass' ";
      $view_class=mysqli_query($con, $sql);
      if(mysqli_num_rows($view_class) == 0){
        echo "<h1 class='text-center'>".$stclass." has no person</h1>";
      }else{
      echo "<div class='container-fluid text-center'>";
      echo "<h1>".$stclass."</h1>";
      echo "<h4>".$stclass.' '."has".' '.mysqli_num_rows($view_class).' '."person(s)</h4>";
      echo "<table class='table table-bordered table-striped'>";
      echo "<th class='text-center'>NAME</th>";
      echo "<th class='text-center'>GENDER</th>";
      echo "<th class='text-center'>OPTIONS</th>";
      while($row=mysqli_fetch_assoc($view_class)){
        $s=mysqli_real_escape_string($con, $row['surname']);
        $m=mysqli_real_escape_string($con, $row['middle_name']);
        $f=mysqli_real_escape_string($con, $row['first_name']);
        $g=mysqli_real_escape_string($con, $row['gender']);
        echo "<tr>";
        echo "<td>".$s.' '.$m.' '.$f."</td>";
        echo "<td>".$g."</td>";
        echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
    }
      break;
    }
  }
}
?>