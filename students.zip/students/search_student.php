<?php

if(isset($_GET['search'])){
    if(!empty($_GET['search_st'])){
        $search_st=mysqli_real_escape_string($con, $_GET['search_st']);
        $sql="SELECT * FROM profiles WHERE surname like '%$search_st%' or middle_name like '%$search_st%' or first_name like '%$search_st%' ";
        $search=mysqli_query($con, $sql);
        if(mysqli_num_rows($search) == 0){
            echo "<br><br><br><h1 class='text-center'>"."No results were found for".' '."<i style='color:red;'>".$search_st."</i>"."</h1>";
        }else{
            echo "<h1 class='text-center'>"."<i style='color:red;'>".mysqli_num_rows($search)."</i>"." results were found for "."<i style='color:red;'>".$search_st."</i>"."</h1>";
            echo "<table class='table table-bordered text-center table-striped table-responsive'>";
            echo "<th class='text-center'>NAME</th>";
            echo "<th class='text-center'>class</th>";
            echo "<th class='text-center'>GENDER</th>";
        while($row=mysqli_fetch_assoc($search)){
            $s=mysqli_real_escape_string($con, $row['surname']);
            $m=mysqli_real_escape_string($con, $row['middle_name']);
            $f=mysqli_real_escape_string($con, $row['first_name']);
            $c=mysqli_real_escape_string($con, $row['class']);
            $g=mysqli_real_escape_string($con, $row['gender']);

            echo "<tr>";
            echo "<td>".$s.' '.$m.' '.$f."</td>";
            echo "<td>".$c."</td>";
            echo "<td>".$g."</td>";
            echo "</tr>";
        }
        echo "</table>";
        }
    }else{
        include 'view_class.php';
    }
}elseif(!isset($_GET['search'])){
    include 'view_class.php'; 
}
?>

