<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../../../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../assets/font-awesome/css/font-awesome.min.css">
    <script src="../../../assets/js/jquery.min.js"></script>
    <script src="../../../assets/js/bootstrap.js"></script>
    <title>Admin ENZY ROYAL SCHOOLS</title>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="#">ENZY ROYAL SCHOOLS</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Dashboard</a></li>
        <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">profiles
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../students">students</a></li>
          <li><a href="../staff">staff</a></li> 
        </ul>
      </li>
      <li><a href="#add_profile" data-toggle="modal">add profile</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="fa fa-sign-out"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<h1 class="text-center">Edit student profile</h1>
<?php include 'edit_student.php'; ?>
<div class="container text-center">
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" formenctype="multipart/data-form">
        
        <div class="col-md-6">
          
          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="stsn" id="" class="form-control" value="<?php echo $_GET['s']; ?>" title="surname">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="stmn" id="" class="form-control" value="<?php echo $_GET['m']; ?>" title="middle name">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="stfn" id="" class="form-control" value="<?php echo $_GET['f']; ?>" title="first name">
            </div>
          </div>
          
          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <select name="stcl" id="" class="form-control" title="class">
                <option value=""><?php echo $_GET['c']; ?></option>
                <option value="NURSERY 1">NURSERY 1</option>
                <option value="NURSERY 2">NURSERY 2</option>
                <option value="NURSERY 3">NURSERY 3</option>
                <option value="PRIMARY 1">PRIMARY 1</option>
                <option value="PRIMARY 2">PRIMARY 2</option>
                <option value="PRIMARY 3">PRIMARY 3</option>
                <option value="PRIMARY 4">PRIMARY 4</option>
                <option value="PRIMARY 5">PRIMARY 5</option>
                <option value="PRIMARY 6">PRIMARY 6</option>
                <option value="JSS 1">JSS 1</option>
                <option value="JSS 2">JSS 2</option>
                <option value="JSS 3">JSS 3</option>
                <option value="SSS 1">SSS 1</option>
                <option value="SSS 2">SSS 2</option>
                <option value="SSS 3">SSS 3</option>
              </select>
            </div>
          </div>
          
          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="date" name="stdob" id="" class="form-control" title="date of birth">
            </div>
          </div>
          
          <div class="form-group">
              <b>Gender</b><br>
              <input type="radio" name="stsex" value="<?php echo $_GET['sex']; ?>" id="" title="male"> Male &nbsp
              <input type="radio" name="stsex" value="<?php echo $_GET['sex']; ?>" id="" title="female"> Female
          </div>
          
          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <select name="stgeno" id="" class="form-control" title="genotype">
                <option value="">-------------------- genotype --------------------</option>
                <option value="AA">AA</option>
                <option value="AS">AS</option>
                <option value="SS">SS</option>
              </select>
            </div>
          </div>
          
          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <select name="stblgrp" id="" class="form-control" title="blood group">
                <option><?php ?></option>
                <option value="A +">A +</option>
                <option value="A -">A -</option>
                <option value="B +">B +</option>
                <option value="B -">B -</option>
                <option value="O +">O +</option>
                <option value="O -">O -</option>
                <option value="AB +">AB +</option>
                <option value="AD -">AB -</option>
              </select>
            </div>
          </div>
        
        </div>
        
        <div class="col-md-6">

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="staddr" id="" class="form-control" value="Residential address" title="residential address">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="stnat" id="" class="form-control" value="Nigerian" title="Nationality">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <select name="stst" id="" class="form-control">
                <option value="">---------- State of Origin ----------</option>
                <?php include '../../../links/db.php'; $states=mysqli_query($con, "SELECT * FROM states");
                while($row=mysqli_fetch_assoc($states)){
                  $state=mysqli_real_escape_string($con, $row['stateName']);
                  echo "<option>".$state."</option>";
                } ?>
              </select>
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="stlga" id="" class="form-control" value="Local government of origin" title="local government of origin">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="parnm" id="" class="form-control" value="<?php ?> title="<?php ?>>
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="tel" name="partel" id="" class="form-control" value="<?php ?>" title="<?php ?>">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="email" name="parmail" id="" class="form-control" value="<?php ?> address" title="<?php ?> address">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="paroccu" id="" class="form-control" value="<?php ?>" title="<?php ?>ation">
            </div>
          </div>

        </div>
          
          <div class="form-group">
            <input type="file" name="stpass" id="" class="form-control" title="students passport">
          </div>

          <input type="submit" name="add_profile" value="add profile" class="btn btn-success">

        </form>
</div>

</body>
</html>