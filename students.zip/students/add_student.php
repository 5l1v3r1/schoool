<?php 
include '../../../links/db.php';

if(isset($_POST['add_profile'])){
    if(!empty($_POST['stsn'])){
        if(!empty($_POST['stmn'])){
            if(!empty($_POST['stfn'])){
                if(!empty($_POST['stcl'])){
                    if(!empty($_POST['stdob'])){
                        if(!empty($_POST['stsex'])){
                            if(!empty($_POST['stgeno'])){
                                if(!empty($_POST['stblgrp'])){
                                    if(!empty($_POST['staddr'])){
                                        if(!empty($_POST['stnat'])){
                                            if(!empty($_POST['stst'])){
                                                if(!empty($_POST['stlga'])){
                                                    if(!empty($_POST['parnm'])){
                                                        if(!empty($_POST['partel'])){
                                                            if(!empty($_POST['parmail'])){
                                                                if(!empty($_POST['paroccu'])){
                                                                    if(!empty($_FILES['stpass'])){
                                                                    

                                                                        
                                                                        $sql="CREATE TABLE IF NOT EXISTS profiles (id VARCHAR(40), 
                                                                        surname VARCHAR(20), middle_name VARCHAR(20), first_name VARCHAR(20), 
                                                                        class VARCHAR(10), date_of_birth VARCHAR(10), gender VARCHAR(10), 
                                                                        genotype VARCHAR(10), blood_group VARCHAR(10), address VARCHAR(100), 
                                                                        nationality VARCHAR(40), state VARCHAR(40), lga VARCHAR(40), 
                                                                        parents_name VARCHAR(40), parents_phone VARCHAR(20), 
                                                                        parents_mail VARCHAR(40), parents_occupation VARCHAR(40), passport VARCHAR(2000)) ";

                                                                        $create_profile_table=mysqli_query($con, $sql);
                                                                        if($create_profile_table){
                                                                            
                                                                            $st=mysqli_real_escape_string($con, rand(100000,999999));
                                                                            $stsn=mysqli_real_escape_string($con, $_POST['stsn']);
                                                                            $stmn=mysqli_real_escape_string($con, $_POST['stmn']);
                                                                            $stfn=mysqli_real_escape_string($con, $_POST['stfn']);
                                                                            $stcl=mysqli_real_escape_string($con, $_POST['stcl']);
                                                                            $stdob=mysqli_real_escape_string($con, $_POST['stdob']);
                                                                            $stsex=mysqli_real_escape_string($con, $_POST['stsex']);
                                                                            $stgeno=mysqli_real_escape_string($con, $_POST['stgeno']);
                                                                            $stblgrp=mysqli_real_escape_string($con, $_POST['stblgrp']);
                                                                            $staddr=mysqli_real_escape_string($con, $_POST['staddr']);
                                                                            $stnat=mysqli_real_escape_string($con, $_POST['stnat']);
                                                                            $stst=mysqli_real_escape_string($con, $_POST['stst']);
                                                                            $stlga=mysqli_real_escape_string($con, $_POST['stlga']);
                                                                            $parnm=mysqli_real_escape_string($con, $_POST['parnm']);
                                                                            $partel=mysqli_real_escape_string($con, $_POST['partel']);
                                                                            $parmail=mysqli_real_escape_string($con, $_POST['parmail']);
                                                                            $paroccu=mysqli_real_escape_string($con, $_POST['paroccu']);
                                                                            $stpass=mysqli_real_escape_string($con, $_FILES['stpass']);       

                                                                            switch($stcl){
                                                                                case "NURSERY 1":
                                                                                $stid="ERSN -".' '.$st;
                                                                                break;

                                                                                case "NURSERY 2":
                                                                                $stid="ERSN -".' '.$st;
                                                                                break;

                                                                                case "NURSERY 3":
                                                                                $stid="ERSN -".' '.$st;
                                                                                break;

                                                                                case "PRIMARY 1":
                                                                                $stid="ERSP -".' '.$st;
                                                                                break;

                                                                                case "PRIMARY 2":
                                                                                $stid="ERSP -".' '.$st;
                                                                                break;

                                                                                case "PRIMARY 3":
                                                                                $stid="ERSP -".' '.$st;
                                                                                break;

                                                                                case "PRIMARY 4":
                                                                                $stid="ERSP -".' '.$st;
                                                                                break;

                                                                                case "PRIMARY 5":
                                                                                $stid="ERSP -".' '.$st;
                                                                                break;

                                                                                case "PRIMARY 6":
                                                                                $stid="ERSP -".' '.$st;
                                                                                break;

                                                                                case "JSS 1":
                                                                                $stid="ERSJS -".' '.$st;
                                                                                break;

                                                                                case "JSS 2":
                                                                                $stid="ERSJS -".' '.$st;
                                                                                break;

                                                                                case "JSS 3":
                                                                                $stid="ERSJS -".' '.$st;
                                                                                break;

                                                                                case "SSS 1":
                                                                                $stid="ERSSS -".' '.$st;
                                                                                break;

                                                                                case "ERSS 2":
                                                                                $stid="ERSSS -".' '.$st;
                                                                                break;

                                                                                case "SSS 3":
                                                                                $stid="ERSSS -".' '.$st;
                                                                                break;

                                                                            }

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["stpass"]["name"]);
$extension = end($temp);

if ((($_FILES["stpass"]["type"] == "image/gif")
|| ($_FILES["stpass"]["type"] == "image/jpeg")
|| ($_FILES["stpass"]["type"] == "image/jpg")
|| ($_FILES["stpass"]["type"] == "image/pjpeg")
|| ($_FILES["stpass"]["type"] == "image/x-png")
|| ($_FILES["stpass"]["type"] == "image/png"))
&& ($_FILES["stpass"]["size"] < 20000)
&& in_array($extension, $allowedExts)) {
   if ($_FILES["stpass"]["error"] > 0) {
    echo "Return Code: " . $_FILES["stpass"]["error"] . "<br>";
  } else {
    echo "Upload: " . $_FILES["stpass"]["name"] . "<br>";
    echo "Type: " . $_FILES["stpass"]["type"] . "<br>";
    echo "Size: " . ($_FILES["stpass"]["size"] / 1024) . " kB<br>";
    echo "Temp file: " . $_FILES["stpass"]["tmp_name"] . "<br>";
    if (file_exists("passports/" . $_FILES["stpass"]["name"])) {
      echo $_FILES["stpass"]["name"] . " already exists. ";
    } else {
      move_uploaded_file($_FILES["stpass"]["tmp_name"],
      "passports/" . $_FILES["stpass"]["name"]);
      $stpass="upload/" . $_FILES["stpass"]["name"];
      echo "Stored in: " . $stpass;
    }
  }
} else {
  echo "Invalid file";
}


                                                                            $sql1="INSERT INTO profiles (id,surname,middle_name,first_name
                                                                            ,class,date_of_birth,gender,genotype,blood_group,address,
                                                                            nationality,state,lga,parents_name,parents_phone,parents_mail,
                                                                            parents_occupation,passport) VALUES ('$stid', '$stsn', '$stmn', '$stfn'
                                                                            , '$stcl', '$stdob', '$stsex', '$stgeno', '$stblgrp', '$staddr', '$stnat',
                                                                             '$stst', '$stlga', '$parnm', '$partel', '$parmail', '$paroccu', '$stpass') ";

                                                                            $insert_profile=mysqli_query($con, $sql1);
                                                                            if($insert_profile){
                                                                                echo "yessssssssssss";
                                                                            }
                                                                            
                                                                            
                                                                        }else{
                                                                            echo "nooooo table";
                                                                        }

                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

?>