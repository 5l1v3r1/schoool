<?php
$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["stpass"]["name"]);
$extension = end($temp);

if ((($_FILES["stpass"]["type"] == "image/gif")
|| ($_FILES["stpass"]["type"] == "image/jpeg")
|| ($_FILES["stpass"]["type"] == "image/jpg")
|| ($_FILES["stpass"]["type"] == "image/pjpeg")
|| ($_FILES["stpass"]["type"] == "image/x-png")
|| ($_FILES["stpass"]["type"] == "image/png"))
&& ($_FILES["stpass"]["size"] < 20000)
&& in_array($extension, $allowedExts)) {
   if ($_FILES["stpass"]["error"] > 0) {
    echo "Return Code: " . $_FILES["stpass"]["error"] . "<br>";
  } else {
    echo "Upload: " . $_FILES["stpass"]["name"] . "<br>";
    echo "Type: " . $_FILES["stpass"]["type"] . "<br>";
    echo "Size: " . ($_FILES["stpass"]["size"] / 1024) . " kB<br>";
    echo "Temp file: " . $_FILES["stpass"]["tmp_name"] . "<br>";
    if (file_exists("passports/" . $_FILES["stpass"]["name"])) {
      echo $_FILES["stpass"]["name"] . " already exists. ";
    } else {
      move_uploaded_file($_FILES["stpass"]["tmp_name"],
      "passports/" . $_FILES["stpass"]["name"]);
      $stpass="upload/" . $_FILES["stpass"]["name"];
      echo "Stored in: " . $stpass;
    }
  }
} else {
  echo "Invalid file";
}

?>
<html>
<body>

<form action="view_student_profile.php" method="post" enctype="multipart/form-data">
<label for="file">Filename:</label>
<input type="file" name="stpass" id="file"><br>
<input type="submit" name="submit" value="Submit">
</form>

</body>
</html>