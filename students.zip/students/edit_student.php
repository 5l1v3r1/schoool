<?php

include '../../../links/db.php';

if(isset($_GET['reg_no'])){
    $id=mysqli_real_escape_string($con, $_GET['reg_no']);
    $sql="SELECT * FROM profiles WHERE id='$id' ";
    $get_pro=mysqli_query($con, $sql);
    while($row=mysqli_fetch_assoc($get_pro)){
        $sn=mysqli_real_escape_string($con, $row['surname']);
    }

}
?>