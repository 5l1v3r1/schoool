<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../../../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../assets/font-awesome/css/font-awesome.min.css">
    <script src="../../../assets/js/jquery.min.js"></script>
    <script src="../../../assets/js/bootstrap.js"></script>
    <title>Admin ENZY ROYAL SCHOOLS</title>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="#">ENZY ROYAL SCHOOLS</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Dashboard</a></li>
        <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">profiles
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../students">students</a></li>
          <li><a href="../staff">staff</a></li> 
        </ul>
      </li>
      <li><a href="#add_profile" data-toggle="modal">add profile</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="fa fa-sign-out"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<h1 class="text-center well well-sm">Student Profiles</h1>
<?php include 'add_student.php'; ?>

<!-- Modal -->
<div id="add_profile" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content text-center">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">ADD STUDENT PROFILE</h4>
      </div>
      <div class="modal-body">
        
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/data-form">
        
        <div class="col-md-6">
          
          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="stsn" id="" class="form-control" placeholder="surname" title="surname">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="stmn" id="" class="form-control" placeholder="middle name" title="middle name">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="stfn" id="" class="form-control" placeholder="first name" title="first name">
            </div>
          </div>
          
          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <select name="stcl" id="" class="form-control" title="class">
                <option value="">-------------------- class --------------------</option>
                <option value="NURSERY 1">NURSERY 1</option>
                <option value="NURSERY 2">NURSERY 2</option>
                <option value="NURSERY 3">NURSERY 3</option>
                <option value="PRIMARY 1">PRIMARY 1</option>
                <option value="PRIMARY 2">PRIMARY 2</option>
                <option value="PRIMARY 3">PRIMARY 3</option>
                <option value="PRIMARY 4">PRIMARY 4</option>
                <option value="PRIMARY 5">PRIMARY 5</option>
                <option value="PRIMARY 6">PRIMARY 6</option>
                <option value="JSS 1">JSS 1</option>
                <option value="JSS 2">JSS 2</option>
                <option value="JSS 3">JSS 3</option>
                <option value="SSS 1">SSS 1</option>
                <option value="SSS 2">SSS 2</option>
                <option value="SSS 3">SSS 3</option>
              </select>
            </div>
          </div>
          
          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="date" name="stdob" id="" class="form-control" title="date of birth">
            </div>
          </div>
          
          <div class="form-group">
              <b>Gender</b><br>
              <input type="radio" name="stsex" value="male" id="" title="male"> Male &nbsp
              <input type="radio" name="stsex" value="female" id="" title="female"> Female
          </div>
          
          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <select name="stgeno" id="" class="form-control" title="genotype">
                <option value="">-------------------- genotype --------------------</option>
                <option value="AA">AA</option>
                <option value="AS">AS</option>
                <option value="SS">SS</option>
              </select>
            </div>
          </div>
          
          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <select name="stblgrp" id="" class="form-control" title="blood group">
                <option value="">-------------------- blood group --------------------</option>
                <option value="A +">A +</option>
                <option value="A -">A -</option>
                <option value="B +">B +</option>
                <option value="B -">B -</option>
                <option value="O +">O +</option>
                <option value="O -">O -</option>
                <option value="AB +">AB +</option>
                <option value="AD -">AB -</option>
              </select>
            </div>
          </div>
        
        </div>
        
        <div class="col-md-6">

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="staddr" id="" class="form-control" placeholder="Residential address" title="residential address">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="stnat" id="" class="form-control" value="Nigerian" title="Nationality">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <select name="stst" id="" class="form-control">
                <option value="">---------- State of Origin ----------</option>
                <?php include '../../../links/db.php'; $states=mysqli_query($con, "SELECT * FROM states");
                while($row=mysqli_fetch_assoc($states)){
                  $state=mysqli_real_escape_string($con, $row['stateName']);
                  echo "<option>".$state."</option>";
                } ?>
              </select>
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="stlga" id="" class="form-control" placeholder="Local government of origin" title="local government of origin">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="parnm" id="" class="form-control" placeholder="Parents name" title="parents name">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="tel" name="partel" id="" class="form-control" placeholder="parents phone" title="parents phone">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="email" name="parmail" id="" class="form-control" placeholder="parents email address" title="parents email address">
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <i class="input-group-addon">
                <i class="fa fa-user"></i>
              </i>
              <input type="text" name="paroccu" id="" class="form-control" placeholder="parents occupation" title="parents occupation">
            </div>
          </div>

        </div>
          
          <div class="form-group">
            <input type="file" name="stpass" id="" class="form-control" title="students passport">
          </div>

          <input type="submit" name="add_profile" value="add profile" class="btn btn-success">

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<div class="row">
<div class="container col-md-6 col-md-offset-3 text-center">
<form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="get">
<input type="search" name="search_st" id="" class="form-control">
<input type="submit" value="search" name="search" class="btn btn-primary">
</form>
</div>
</div>



<div class="container" >
<?php include 'search_student.php'; ?>
</div>
</body>
</html>

<script>
  function passId(id){
     $("#reg_no").val(id);
  }
</script>