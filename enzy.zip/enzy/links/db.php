<?php 

$db_host="localhost";
$db_pass="";
$db_user="root";
$db_name="enzy";

$con=mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if(!$con){
    echo "unable to connect";
}

?>